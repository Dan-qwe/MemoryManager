package so.schedule;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import so.Process;
import so.SubProcess;

public class Lotery extends SchedulerQueue{
	public Lotery() {
		super(new Comparator<Process>() {

			@Override
			public int compare(Process sp1, Process sp2) {
				return sp1.getTimeToExecute() >= sp2.getTimeToExecute() ?
						1 : -1;
						}
			
		});
	}
	@Override
    public SubProcess execute() {
        int totalTickets = calculateTotalTickets();
        if (totalTickets == 0) return null; // Retorna null se não houver processos na fila ou nenhum bilhete distribuído

        Random random = new Random();
        int winningTicket = random.nextInt(totalTickets) + 1; // Sorteia um número entre 1 e o total de bilhetes

        int accumulatedTickets = 0;
        for (Process process : getQueue()) {
            List<SubProcess> subProcesses = getsubProcesses().get(process.getId());
            int tickets = subProcesses.size(); // Cada sub-processo pode ser considerado um bilhete
            accumulatedTickets += tickets;
            if (accumulatedTickets >= winningTicket) {
                return subProcesses.remove(0); // Retorna o primeiro sub-processo do processo selecionado
            }
        }
        return null; // Alcançado apenas se houver um erro na lógica de distribuição de bilhetes
    }

    @Override
    public Map<String, Integer> getQuantumTable() {
        return null; // Retorna null, já que não há um conceito de quantum na Loteria
    }

    private int calculateTotalTickets() {
        int totalTickets = 0;
        for (Process process : getQueue()) {
            totalTickets += getSubProcess().get(process.getId()).size();
        }
        return totalTickets;
    }

	

}
