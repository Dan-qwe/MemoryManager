package so.schedule;

import java.util.Comparator;

import so.Process;

public class RoundRobin extends SchedulerQueue{

	public RoundRobin(Comparator<Process> comparator) {
		super(comparator);
		// TODO Auto-generated constructor stub
	}

	

}
