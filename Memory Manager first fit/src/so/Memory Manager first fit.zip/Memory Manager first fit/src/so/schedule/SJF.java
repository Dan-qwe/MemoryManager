package so.schedule;

import java.util.Comparator;
import java.util.Map;

import so.Process;
import so.SubProcess;

public class SJF extends SchedulerQueue{
	
	
	public SJF() {
		super(new Comparator<Process>() {

			@Override
			public int compare(Process sp1, Process sp2) {
				return sp1.getTimeToExecute() >= sp2.getTimeToExecute() ?
						1 : -1;
						}
			
		});
	}

	@Override
	public SubProcess execute() {
        return null;
	}
    

	@Override
	public Map<String, Integer> getQuantumTable() {
		// TODO Auto-generated method stub
		return null;
	}



}
