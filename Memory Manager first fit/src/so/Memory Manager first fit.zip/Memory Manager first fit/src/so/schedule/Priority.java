package so.schedule;

import java.util.Comparator;
import java.util.Map;

import so.Process;
import so.SubProcess;
 
public class Priority extends SchedulerQueue {


	public Priority() {
		super(new Comparator<Process>() {

			@Override
			public int compare(Process p1, Process p2) {
				return p1.getPriority().getlevel() >= p2.getPriority().getlevel() ? 
						1 : -1;
			}

		});
	}

	@Override
	public SubProcess execute() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Integer> getQuantumTable() {
		// TODO Auto-generated method stub
		return null;
	}

}


