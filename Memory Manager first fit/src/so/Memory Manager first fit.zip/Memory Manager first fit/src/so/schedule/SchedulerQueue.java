package so.schedule;

import java.util.Comparator;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

import so.Process;
import so.SubProcess;
import so.SystemCallType;
import so.SystemOperation;
import so.cpu.Core;

public abstract class SchedulerQueue extends Scheduler{

	private PriorityQueue<Process> queue;
	private Hashtable<String, List<SubProcess>> subProcesses;
	
	public SchedulerQueue(Comparator<Process> comparator) {
		this.queue = new PriorityQueue<Process>(comparator);
		this.subProcesses = new Hashtable<>();
	}

	@Override
	public void execute(Process p) {
		this.queue.add(p);
		List<SubProcess> sps = SystemOperation.SystemCall(SystemCallType.READ, p);
		this.subProcesses.put(p.getId(), sps); 
		this.registerProcess();
	}
	
	public void registerProcess() {
		Process p = this.queue.poll();
		List<SubProcess> sps = this.subProcesses.get(p.getId());
		Core[] cores = this.getCpu().getCores();
		for(Core core: cores) {
			if(core.getSubProcess() == null) {
				SubProcess sp = sps.get(0);
				this.getCpu().registerProcess(core.getId(), sp);
			}
		}
		
	}

	@Override
	public void finish(Process p) {
		
	}

	public PriorityQueue<Process> getQueue() {
		return queue;
	}
	
}
