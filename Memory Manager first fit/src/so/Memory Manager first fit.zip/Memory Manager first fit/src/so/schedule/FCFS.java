package so.schedule;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import so.Process;
import so.SubProcess;
import so.SystemCallType;
import so.SystemOperation;
import so.cpu.Core;

public class FCFS extends SchedulerQueue{
	
	
	
	public FCFS () {
		super(new Comparator<Process>() {

			@Override
			public int compare(Process sp1, Process sp2) {
				return -1;
			}
			});
		
		
	}

	@Override
	public SubProcess execute() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Integer> getQuantumTable() {
		// TODO Auto-generated method stub
		return null;
	}

	


}
