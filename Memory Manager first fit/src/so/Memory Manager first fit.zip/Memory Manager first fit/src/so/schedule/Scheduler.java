package so.schedule;
import java.util.Map;

import so.Process;
import so.cpu.CpuManager;
import so.SubProcess;

public abstract class Scheduler {
	
	private CpuManager cpu;
	
	public Scheduler() { 
		this.cpu = new CpuManager(this);
	}	
	
	public CpuManager getCpu() {
		return cpu;
	}
	public void setCpu(CpuManager cpu) {
		this.cpu = cpu;
	}
	public abstract SubProcess execute();
	public abstract void execute(Process p);
	public abstract void finish(Process p);
	public abstract Map<String, Integer> getQuantumTable();
	
}
