package so;

public class Execute {
	public static void main(String[] args) {
				System.out.println(" \n *************************Processo 01***************************** \n");				
				Process p1 = SystemOperation.SystemCall(SystemCallType.CREATE, 130);
				SystemOperation.SystemCall(SystemCallType.WRITE, p1);
				
				System.out.println(); 
				System.out.println(" \n **************************Processo 02**************************** \n");
				Process p2 = SystemOperation.SystemCall(SystemCallType.CREATE, 90);
				SystemOperation.SystemCall(SystemCallType.WRITE, p2);
				
				System.out.println();
				System.out.println(" \n ***************************Processo 03*************************** \n");
				Process p3 = SystemOperation.SystemCall(SystemCallType.CREATE, 35);
				SystemOperation.SystemCall(SystemCallType.WRITE, p3);
				
				
				
		
		
		 }
	
	 
    
	 
	
	
	}


/*
 * Process p4 = SystemOperation.SystemCall(SystemCallType.CREATE, null, 6,"p4");
 * SystemOperation.SystemCall(SystemCallType.WRITE, p4, 0,"p4");
 * 
 * Process p5 = SystemOperation.SystemCall(SystemCallType.CREATE, null, 6,"p5");
 * SystemOperation.SystemCall(SystemCallType.WRITE, p5, 0,"p5");
 * 
 * 
 * SystemOperation.SystemCall(SystemCallType.DELETE, p1, 0, "p1");
 * 
 * 
 * 
 * 
 * 
 * Process p6 = SystemOperation.SystemCall(SystemCallType.CREATE, null, 2,"p6");
 * SystemOperation.SystemCall(SystemCallType.WRITE, p6, 0,"p6");
 */