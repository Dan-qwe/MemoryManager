package so;


public class SubProcess {
	private String id;
	private int instructions;
	public static int count;
	private Process process;
		
	public SubProcess(String processId, int instructions) {
		this.id = processId + count; 
		this.instructions = instructions;
		count++;
	} 
	public static void resetCount() {
        count = 0;
    }
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getInstructions() {
		return instructions; 
	}
	public void setInstructions(int instructions) {
		this.instructions = instructions;
	}
	public Process getProcess() {
        return this.process;
    }
	
	
}
