package so;

public class conta {

    static void worstFit(int tamBloco[], int m, int process[], int n) {
        int local[] = new int[n];
        for (int i = 0; i < local.length; i++)
            local[i] = -1;

        for (int i = 0; i < n; i++) {
            int worstId = -1;
            for (int j = 0; j < m; j++) {
                if (tamBloco[j] >= process[i]) {
                    if (worstId == -1 || tamBloco[worstId] < tamBloco[j]) {
                        worstId = j;
                    }
                }
            }

            if (worstId != -1) {
                local[i] = worstId;
                tamBloco[worstId] -= process[i];
                System.out.println("Processo " + (i + 1) + " alocado no bloco " + (worstId + 1));
            } else {
                System.out.println("Processo " + (i + 1) + " é maior que todos os blocos disponíveis.");
            }
        }

        compactMemory(tamBloco, m);

        System.out.println("\nNum.Processo \tTamanho Pro.\tBlocos alocados.");
        for (int i = 0; i < n; i++) {
            System.out.print("   " + (i + 1) + "\t\t" + process[i] + "\t\t");
            if (local[i] != -1) {
                System.out.print(local[i] + 1);
            }
            System.out.println();
        }
    }

    static void compactMemory(int tamBloco[], int m) {
        int j = 0;
        for (int i = 0; i < m; i++) {
            if (tamBloco[i] > 0) {
                tamBloco[j] = tamBloco[i];
                j++;
            }
        }
        for (int i = j; i < m; i++) {
            tamBloco[i] = 0;
        }
    }

    // Colocar dados
    public static void main(String[] args) {
        int tamBloco[] = {36,30};
        int process[] = {8,12, 22, 14, 4, 2};
        int m = tamBloco.length;
        int n = process.length;

        worstFit(tamBloco, m, process, n);
    }
}