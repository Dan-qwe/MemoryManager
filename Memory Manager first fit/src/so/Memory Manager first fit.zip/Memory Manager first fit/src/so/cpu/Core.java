package so.cpu;

import so.SubProcess;

public class Core implements Runnable{
	
	private int id;
	private SubProcess subProcess;
	private int numOfInstructionsPerClock;
	
	private int count;
	
	public Core (int coreId, int numOfInstructionsPerClock){
		this.id = coreId; 
		this.numOfInstructionsPerClock = numOfInstructionsPerClock;
	}
	 
	@Override
	public void run() { 
		if(this.subProcess != null) {
			this.count += numOfInstructionsPerClock;
			if (this.count>= this.subProcess.getInstructions()) {
				this.finshExecution();
			} 			
		}
	}

	private void finshExecution() {
		this.subProcess = null;
		this.count = 0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public SubProcess getSubProcess() {
		return subProcess;
	}

	public void setSubProcess(SubProcess subProcess) {
		this.subProcess = subProcess;
	}
	
}
