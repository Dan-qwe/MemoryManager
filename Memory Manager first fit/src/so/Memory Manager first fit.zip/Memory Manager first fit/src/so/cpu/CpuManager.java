package so.cpu;

import java.util.Timer;
import java.util.TimerTask;

import so.schedule.*;
import so.SubProcess;

public class CpuManager {
	private Core[] cores;
	public static int NUM_OF_INSTRUCTIONS_PER_CLOCK= 7;
	public static int CLOCK_TIME = 500;
	public static int NUM_OF_CLOCKS = 4;
	private Scheduler scheduler;
	
	public CpuManager (Scheduler scheduler) {
		this.cores = new Core[NUM_OF_CLOCKS]; 
		for(int i = 0; i < this.cores.length; i ++) {
			this.cores[i] = new Core(i, NUM_OF_INSTRUCTIONS_PER_CLOCK);
		}
		this.scheduler = scheduler;
		this.clock();
	} 
	public void registerProcess(int coreId, SubProcess p) { 
		this.cores[coreId].setSubProcess(p);
	}
	
	
	private void clock() {
		TimerTask tt = new TimerTask() {
			@Override
			public void run() {
				System.out.println("Executando processo");
				executeProcess();
			}
		};
		new Timer().scheduleAtFixedRate(tt, 0, CLOCK_TIME);
	}
	
	
	private void executeProcess() {
		for(int i = 0; i < this.cores.length; i++) {
			this.cores[i].run();
		} 
		printProcessor();
	}
	private void printProcessor() {
		/*
		 * for(Core core: this.cores) { if(core.getSubProcess() != null) {
		 * System.out.print(core.getSubProcess().getId() + " | ");
		 * 
		 * } }
		 */
		int count = 0;
        SubProcess data = null;
        for (Core core : cores) {
            data = this.scheduler.execute();
            if (data != null) {
                if (core.getSubProcess() != null) {
                    core.setSubProcess(data);
                    core.run();
                    count++;
                    if (this.scheduler != null && count == 4) {
                    	if (this.scheduler.getQuantumTable() != null) {
                    		
                    		if (this.scheduler.getQuantumTable().get(data.getProcess().getId()) != 0) {        			
                    			System.out.println(this.scheduler.getQuantumTable().get(data.getProcess().getId()));
                    		}
                    	}
                	}
                }
            }
        }

        if (data != null) {
        }
	}
	public Core[] getCores() {
		return cores;
	}
	
	
	
}
