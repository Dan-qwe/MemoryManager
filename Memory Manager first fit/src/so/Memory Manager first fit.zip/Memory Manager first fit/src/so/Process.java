package so;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Process {
	private String id;
	private int sizeInMemory;
	private List<String> subProcesses;
	private static int countIndex = 0;
	
	private int timeToExecute;	
	private Priority priority;
	
	public Process(int size) {		
		countIndex++; 
		
		SubProcess.count = 0;
		this.id = "P"+ 	countIndex; 
		this.sizeInMemory = size; 
		Random rand = new Random();
		
		List<Integer> TimeList = Arrays.asList(100,200,300,400,500,600,700,800,900,1000,2000);
		this.timeToExecute = TimeList.get(rand.nextInt(TimeList.size()));
		
		List<Priority> otherList = Arrays.asList(Priority.BAIXA, Priority.MEDIA, Priority.ALTA, Priority.CRITICA);
		this.priority = otherList.get(rand.nextInt(otherList.size()));	
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getSizeInMemory() {
		return sizeInMemory;
	}
	public void setSizeInMemory(int sizeInMemory) {
		this.sizeInMemory = sizeInMemory;
	}
	public List<String> getsubProcesses() {
        return this.subProcesses;
    }
	
	public List<String> getSubProcesses(){
		if(this.subProcesses == null || this.subProcesses.isEmpty()) {
			
			this.subProcesses = new LinkedList<>();
			for (int i = 0; i < this.getSizeInMemory();i++) {
				this.subProcesses.add(id + i);
			}
		}	
		return this.subProcesses;
		
	}
	public int getTimeToExecute() {
		return timeToExecute;
	}
	public void setTimeToExecute(int timeToExecute) {
		this.timeToExecute = timeToExecute;
	}
	public Priority getPriority() {
		return priority;
	}
	public void setPriority(Priority priority) {
		this.priority = priority;
	}
	
	
	
	
}
