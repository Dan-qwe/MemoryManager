package so;

import java.util.List;

import so.memory.MemoryManager;
import so.schedule.FCFS;
import so.schedule.Lotery;
import so.schedule.SJF;
import so.schedule.Scheduler;

public class SystemOperation {
	private static MemoryManager mm;

	private static Scheduler scheduler;

	public static Process SystemCall(SystemCallType type, int ProcessSize) {
		if (type.equals(SystemCallType.CREATE)) {
			if (scheduler == null) {
				// AQUI É ONDE SE ALTERA AS ESTRATEGIAS
				scheduler = new SJF();
			}
			if (mm == null) {
				mm = new MemoryManager(4, 256);
			}
			else {
				System.out.println(" ");
                System.out.println("!!!!!!!!!!!!!!!   P A GE  F A U L T   !!!!!!!!!!!!!!!");
                System.out.println(" ");
			}
		}
		return new Process(ProcessSize);
	}

	public static List<SubProcess> SystemCall(SystemCallType type, Process p) {
		if (type.equals(SystemCallType.WRITE)) {
			mm.writeProcess(p);
			scheduler.execute(p);
		}

		else if (type.equals(SystemCallType.DELETE)) {
			scheduler.finish(p);
			mm.deleteProcess(p);

		}

		else if (type.equals(SystemCallType.READ)) {
			return mm.read(p);
		}
		return null;

	}
}
