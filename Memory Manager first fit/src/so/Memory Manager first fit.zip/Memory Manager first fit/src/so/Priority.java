package so;

public enum Priority {
	BAIXA(0), MEDIA(1), ALTA(2), CRITICA(2000);
	private int level;
	 Priority(int level) {
		 this.level = level;
	}
	public int getlevel() {
		return level;
	}
	public void setlevel(int level) {
		this.level = level;
	}
	
	 
	
}
