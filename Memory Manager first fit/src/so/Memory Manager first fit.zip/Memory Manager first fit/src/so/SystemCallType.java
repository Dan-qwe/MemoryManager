package so;

public enum SystemCallType { 
	DELETE, READ, WRITE, CREATE
}
