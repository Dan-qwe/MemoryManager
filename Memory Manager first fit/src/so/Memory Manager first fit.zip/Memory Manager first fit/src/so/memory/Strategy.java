package so.memory;

public enum Strategy {
	FIRST_FIT, BEST_FIT, WORST_FIT, PAGING
}
