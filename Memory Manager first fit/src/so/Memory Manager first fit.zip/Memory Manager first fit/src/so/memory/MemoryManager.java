package so.memory;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

import so.Process;
import so.SubProcess;

public class MemoryManager {

	private SubProcess[][] physicMemory;
	private Hashtable<String, FrameMemory> logicalMemory;
	private int pageSize;

	public static int NUMBER_OF_PROCESS_INSTRUCTIONS = 7;

	public MemoryManager(int pageSize, int memorySize) {
		this.pageSize = pageSize;
		int pages = memorySize / pageSize;
		physicMemory = new SubProcess[pages][this.pageSize];
		logicalMemory = new Hashtable<>();

	}

	public void write(Process p) {
		this.writeProcess(p);
	}

	public void writeProcess(Process p) {
		List<FrameMemory> frames = this.getFrames(p);
		int increment = 0; // gambiarra		
		for (int i = 0; i < frames.size(); i++) {
			FrameMemory frame = frames.get(i);
			for (int offset = 0; offset < this.pageSize; offset++) {
					SubProcess sp = new SubProcess(p.getId(), NUMBER_OF_PROCESS_INSTRUCTIONS);
					if(increment < p.getSubProcesses().size()) {
						
						this.physicMemory[frame.getFrameNumber()][offset] = sp;
						
						frame.setOffset(offset);
						
						this.logicalMemory.put(sp.getId(), frame);
						increment++;
					}

				}

			}
		 
		SubProcess.resetCount();
		this.printStatusMemory();
	}

	private List<FrameMemory> getFrames(Process p) {
		List<FrameMemory> frames = new LinkedList<>();
		int totalOfPages = (int) Math.ceil((double)p.getSizeInMemory() / this.pageSize);
		for (int frame = 0; frame < this.physicMemory.length; frame++) {
			if (this.physicMemory[frame][0] == null) {
				frames.add(new FrameMemory(frame, 0));
				if (frames.size() >= totalOfPages) {
					return frames;
				}
			}
		}
		return new LinkedList<>();
	}
	/*
	 * opcao alternativa ainda nao confirmada private void printStatusMemory() { for
	 * (int i = 0; i < this.physicMemory.length; i++) { for (int j = 0; j <
	 * this.pageSize; j++) { // da pra melhorar e muito SubProcess sp =
	 * this.physicMemory[i][j]; String spId = null; if (sp != null) { spId =
	 * sp.getId(); } if (j == this.physicMemory[i].length - 1) {
	 * System.out.println(spId); } else { System.out.println(spId + " | "); }
	 * 
	 * } } }
	 */

	private void printStatusMemory() {
		for (int i = 0; i < this.physicMemory.length; i++) {
			for (int j = 0; j < this.pageSize; j++) {
				// da pra melhorar e muito
				if (j == (this.pageSize - 1)) {
					if (this.physicMemory[i][j] != null) {
						System.out.println(this.physicMemory[i][j].getId());

					} else {
						System.out.println(this.physicMemory[i][j]);
					}
				}

				else {
					if (this.physicMemory[i][j] != null) {
						System.out.print(this.physicMemory[i][j].getId() + "|");

					} else {
						System.out.print(this.physicMemory[i][j] + "|");
					}
				}

			}
		}
	}
	public List<SubProcess> read(Process p) {
	    List<String> ids = p.getSubProcesses();
	    List<SubProcess> sps = new LinkedList<>();
	    for (String id : ids) {
	        FrameMemory frame = this.logicalMemory.get(id);
	        // Verifica se frame não é nulo antes de acessar seus métodos
	        if (frame != null) {
	            sps.add(this.physicMemory[frame.getFrameNumber()][frame.getOffset()]);
	        }
	    }
	    return sps;
	} 
	
	
	
	

	public void deleteProcess(Process p) {
		for (int i = 0; i < physicMemory.length; i++) {
			if (physicMemory[i] != null && physicMemory[i].equals(p.getId())) {
				physicMemory[i] = null;
			}
		}
		System.out.println("Processo " + p.getId() + " removido da memória.");
		printStatusMemory();
		
		/*
		 * for (int i = 0; i < physicMemory.length; i++) { if (physicMemory[i] != null
		 * && physicMemory[i].equals(p.getId())) { physicMemory[i] = null; } }
		 * System.out.
		 * println("\n  ------------------------------------------------------");
		 * System.out.println("\n Processo " + p.getId() + " removido da memória.");
		 * printStatusMemory();
		 */

	}

}