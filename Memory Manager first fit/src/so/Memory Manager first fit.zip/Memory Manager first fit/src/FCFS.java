import java.util.LinkedList;
import java.util.Queue;

class Process {
    private String id;
    private int arrivalTime;
    private int burstTime;

    public Process(String id, int arrivalTime, int burstTime) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
    }

    public String getId() {
        return id;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }

    public int getBurstTime() {
        return burstTime;
    }
}

public class FCFS {
    public static void main(String[] args) {
        // Cria uma fila de processos
        Queue<Process> queue = new LinkedList<>();

        // Adiciona alguns processos à fila
        queue.add(new Process("P1", 0, 5));
        queue.add(new Process("P2", 2, 3));
        queue.add(new Process("P3", 4, 6));
        queue.add(new Process("P4", 6, 4));

        // Executa o algoritmo FCFS
        executeFCFS(queue);
    }

    public static void executeFCFS(Queue<Process> queue) {
        int currentTime = 0;

        while (!queue.isEmpty()) {
            Process currentProcess = queue.poll();

            // Se o processo chegou depois do tempo atual, avança o tempo para o momento em que ele chega
            if (currentProcess.getArrivalTime() > currentTime) {
                currentTime = currentProcess.getArrivalTime();
            }

            // Executa o processo
            System.out.println("Executando processo " + currentProcess.getId() + " de " +
                    currentTime + " até " + (currentTime + currentProcess.getBurstTime()));

            // Avança o tempo
            currentTime += currentProcess.getBurstTime();
        }
    }
}
